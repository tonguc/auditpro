AuditPro — 211-Point UX + SEO + CRO + AI Visibility Audit Toolkit
Version 1.0
================================================================

WHAT'S IN THIS ZIP
------------------
  auditpro-offline.html       — The main audit tool (open in Chrome or Edge)
  QuickStart.html             — Step-by-step guide (open in any browser or print)
  Sample_Full_Audit.pdf       — Sample PDF: full audit, 100% coverage, Grade B (86/100)
  Sample_Partial_Audit.pdf    — Sample PDF: partial audit, 40% coverage, grade withheld (Directional Reviewed Score)
  README.txt                  — This file

HOW TO START
------------
1. Extract the ZIP to any folder on your computer.
2. Double-click auditpro-offline.html — opens directly in your browser.
   Chrome or Edge recommended for best PDF export quality.
3. Click "Start First Audit" or "Load Demo Audit" to explore.
4. For full instructions, open QuickStart.html.

IMPORTANT: HOW SCORING WORKS
-----------------------------
AuditPro is a MANUAL audit toolkit. You review each checkpoint yourself
and mark the result. It does not crawl or automatically analyze websites.

- Scores are calculated only from reviewed, applicable checkpoints.
- Blank items (not yet reviewed) and N/A items are excluded from scoring.
- Higher coverage = higher confidence in your results.
- Letter grades appear only when 60%+ of relevant checkpoints are reviewed.
  Below that threshold, AuditPro shows a directional or preliminary score,
  clearly labelled with its confidence level.
- Partial audits are useful for early diagnostics.
- Full audits (60%+ coverage) are recommended for final client deliverables.

IMPORTANT NOTES
---------------
- This is a MANUAL audit toolkit. You review each checkpoint yourself.
  It is not an automated crawler or SEO analyzer.
- No internet connection required. No account or subscription needed.
- All data is stored in your browser's local storage (not on any server).
- Clearing browser data will erase your audits. Use Export Backup regularly.
- Chrome and Edge are recommended. Avoid closing the tab during PDF export.

WHITE LABEL PDF EXPORT
----------------------
Go to the "White Label PDF" tab to add your agency name, logo,
brand color, and contact info. Every exported PDF will carry your brand.

BACKUP & RESTORE
----------------
White Label > Data & Backup > Export Backup — saves a .json file.
Import Backup — restores all audits on a new device or after clearing data.

LICENSE
-------
Single-agency license. For use by one person or one agency only.
Redistribution, resale, or sharing outside your agency is not permitted.

(c) 2025 AuditPro. All rights reserved.
